// =============================
// Fake Database
// =============================
let tasks = [
  { id: 1, title: "Learn JavaScript Promises", completed: false },
  { id: 2, title: "Build Promise Project", completed: false }
];

// DOM elements
const taskList = document.getElementById("taskList");
const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const message = document.getElementById("message");
const loader = document.getElementById("loader");

// =============================
// Utility Functions
// =============================

// Show loader
function showLoader() {
  loader.classList.remove("hidden");
}

// Hide loader
function hideLoader() {
  loader.classList.add("hidden");
}

// Show message
function showMessage(text, color = "black") {
  message.textContent = text;
  message.style.color = color;
}

// Render tasks in UI
function renderTasks(taskArray) {
  taskList.innerHTML = "";

  if (taskArray.length === 0) {
    taskList.innerHTML = "<li>No tasks available</li>";
    return;
  }

  taskArray.forEach(task => {
    const li = document.createElement("li");
    li.className = task.completed ? "completed" : "";

    li.innerHTML = `
      <span>${task.title}</span>
      <div class="btn-group">
        <button class="complete-btn" onclick="markComplete(${task.id})">Complete</button>
        <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
      </div>
    `;

    taskList.appendChild(li);
  });
}

// =============================
// Promise Based Fake API
// =============================

// Fetch all tasks
function fetchTasks() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (tasks) {
        resolve(tasks);
      } else {
        reject("Failed to fetch tasks");
      }
    }, 1000);
  });
}

// Add new task
function addTask(title) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!title.trim()) {
        reject("Task title cannot be empty");
        return;
      }

      const newTask = {
        id: Date.now(),
        title: title,
        completed: false
      };

      tasks.push(newTask);
      resolve(newTask);
    }, 1000);
  });
}

// Mark task as complete
function completeTask(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const task = tasks.find(t => t.id === id);

      if (!task) {
        reject("Task not found");
        return;
      }

      task.completed = true;
      resolve(task);
    }, 1000);
  });
}

// Delete task
function removeTask(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const index = tasks.findIndex(t => t.id === id);

      if (index === -1) {
        reject("Task not found");
        return;
      }

      const deletedTask = tasks.splice(index, 1);
      resolve(deletedTask[0]);
    }, 1000);
  });
}

// =============================
// Load Initial Tasks
// =============================
function loadTasks() {
  showLoader();
  showMessage("Loading tasks...", "blue");

  fetchTasks()
    .then(data => {
      renderTasks(data);
      showMessage("Tasks loaded successfully", "green");
    })
    .catch(error => {
      showMessage(error, "red");
    })
    .finally(() => {
      hideLoader();
    });
}

// =============================
// Add Task Event
// =============================
addTaskBtn.addEventListener("click", () => {
  const title = taskInput.value;

  showLoader();
  showMessage("Adding task...", "blue");

  addTask(title)
    .then(newTask => {
      showMessage(`Task added: ${newTask.title}`, "green");
      taskInput.value = "";
      return fetchTasks(); // chain promise
    })
    .then(updatedTasks => {
      renderTasks(updatedTasks);
    })
    .catch(error => {
      showMessage(error, "red");
    })
    .finally(() => {
      hideLoader();
    });
});

// =============================
// Complete Task
// =============================
function markComplete(id) {
  showLoader();
  showMessage("Updating task...", "blue");

  completeTask(id)
    .then(task => {
      showMessage(`Task completed: ${task.title}`, "green");
      return fetchTasks();
    })
    .then(updatedTasks => {
      renderTasks(updatedTasks);
    })
    .catch(error => {
      showMessage(error, "red");
    })
    .finally(() => {
      hideLoader();
    });
}

// =============================
// Delete Task
// =============================
function deleteTask(id) {
  showLoader();
  showMessage("Deleting task...", "blue");

  removeTask(id)
    .then(task => {
      showMessage(`Task deleted: ${task.title}`, "green");
      return fetchTasks();
    })
    .then(updatedTasks => {
      renderTasks(updatedTasks);
    })
    .catch(error => {
      showMessage(error, "red");
    })
    .finally(() => {
      hideLoader();
    });
}

// =============================
// Initial Call
// =============================
loadTasks();