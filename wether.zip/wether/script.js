const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const message = document.getElementById("message");

const cityName = document.getElementById("cityName");
const temperature = document.getElementById("temperature");
const windspeed = document.getElementById("windspeed");
const weathercode = document.getElementById("weathercode");

// message show function
function showMessage(text, color = "black") {
  message.textContent = text;
  message.style.color = color;
}

// weather code ko readable text me convert karne ke liye
function getWeatherText(code) {
  if (code === 0) return "Clear sky";
  if (code === 1 || code === 2 || code === 3) return "Partly cloudy";
  if (code === 45 || code === 48) return "Fog";
  if (code === 51 || code === 53 || code === 55) return "Drizzle";
  if (code === 61 || code === 63 || code === 65) return "Rain";
  if (code === 71 || code === 73 || code === 75) return "Snow";
  if (code === 95) return "Thunderstorm";
  return "Unknown";
}

// city search aur weather fetch
async function getWeather() {
  const city = cityInput.value.trim();

  if (city === "") {
    showMessage("Please enter a city name", "red");
    return;
  }

  showMessage("Fetching weather data...", "blue");

  try {
    // Step 1: Get latitude and longitude from city name
    const geoResponse = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${city}&count=1`
    );

    if (!geoResponse.ok) {
      throw new Error("Failed to fetch location data");
    }

    const geoData = await geoResponse.json();

    if (!geoData.results || geoData.results.length === 0) {
      throw new Error("City not found");
    }

    const location = geoData.results[0];
    const lat = location.latitude;
    const lon = location.longitude;
    const fullCityName = location.name;

    // Step 2: Get weather data using latitude and longitude
    const weatherResponse = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`
    );

    if (!weatherResponse.ok) {
      throw new Error("Failed to fetch weather data");
    }

    const weatherData = await weatherResponse.json();
    const current = weatherData.current_weather;

    // Display data
    cityName.textContent = `City: ${fullCityName}`;
    temperature.textContent = `Temperature: ${current.temperature}°C`;
    windspeed.textContent = `Wind Speed: ${current.windspeed} km/h`;
    weathercode.textContent = `Condition: ${getWeatherText(current.weathercode)}`;

    showMessage("Weather data loaded successfully", "green");
  } catch (error) {
    showMessage(error.message, "red");

    cityName.textContent = "City: --";
    temperature.textContent = "Temperature: --";
    windspeed.textContent = "Wind Speed: --";
    weathercode.textContent = "Weather Code: --";
  }
}

searchBtn.addEventListener("click", getWeather);

cityInput.addEventListener("keyup", function (e) {
  if (e.key === "Enter") {
    getWeather();
  }
});f